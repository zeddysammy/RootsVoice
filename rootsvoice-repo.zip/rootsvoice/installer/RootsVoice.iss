; RootsVoice installer wizard (Inno Setup 6)
; Built automatically by build_installer.bat - you do not need to open this file.

#define MyAppName "RootsVoice"
#define MyAppVersion "2.2.3"
; Windows file version: always four numbers
#define MyAppFileVersion "2.2.3.0"
#define MyAppPublisher "nightfellas"
#define MyAppExeName "RootsVoice.exe"
#define MyAppDescription "Voice-controlled scripture for your projection software"

[Setup]
; AppId identifies RootsVoice for upgrades and uninstall - never change it between versions.
AppId={{8D3C1E0A-5B7F-4E2D-9A61-3F2B7C9E4D15}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppCopyright=Copyright (C) 2026 {#MyAppPublisher}
AppComments={#MyAppDescription}
VersionInfoCompany={#MyAppPublisher}
VersionInfoProductName={#MyAppName}
VersionInfoDescription={#MyAppName} Setup
VersionInfoVersion={#MyAppFileVersion}
VersionInfoCopyright=Copyright (C) 2026 {#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
; Lets the person choose "install for me only" (no admin password) or "for all users".
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=..\dist
OutputBaseFilename=RootsVoice-Setup-{#MyAppVersion}
SetupIconFile=..\assets\roots.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
UninstallDisplayName={#MyAppName}
WizardStyle=modern
WizardImageFile=..\assets\wizard-large.bmp,..\assets\wizard-large-2x.bmp
WizardSmallImageFile=..\assets\wizard-small.bmp,..\assets\wizard-small-2x.bmp
Compression=lzma2/max
SolidCompression=yes
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Messages]
WelcomeLabel2=This will install [name/ver] on your computer.%n%nRootsVoice listens for Bible references and shows them in VideoPsalm, BibleShow, EasyWorship, ProPresenter, OpenLP or FreeShow. Everything it needs is included - there is nothing else to install.%n%nPlease close RootsVoice before continuing.

[Types]
Name: "full"; Description: "Recommended - works offline straight away"
Name: "compact"; Description: "Smaller - the speech model downloads the first time you press Start"
Name: "custom"; Description: "Custom"; Flags: iscustom

[Components]
Name: "app"; Description: "RootsVoice"; Types: full compact custom; Flags: fixed
#ifndef NOMODEL
Name: "model"; Description: "Speech model (base.en, about 145 MB) - lets RootsVoice work without internet"; Types: full
#endif

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"
Name: "startup"; Description: "Start RootsVoice when Windows starts"; GroupDescription: "Other options:"; Flags: unchecked

[Files]
Source: "..\build\pyinstaller\dist\RootsVoice\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Components: app
#ifndef NOMODEL
Source: "..\build\models\base.en\*"; DestDir: "{app}\models\base.en"; Flags: ignoreversion recursesubdirs createallsubdirs; Components: model
#endif

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Comment: "{#MyAppDescription}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Comment: "{#MyAppDescription}"; Tasks: desktopicon
Name: "{userstartup}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: startup

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#MyAppName}}"; Flags: nowait postinstall skipifsilent

[Code]
// When uninstalling, offer to remove the person's settings, training and downloaded models too.
// They live in %APPDATA%\RootsVoice so they survive upgrades.
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  DataDir: String;
begin
  if CurUninstallStep = usPostUninstall then
  begin
    DataDir := ExpandConstant('{userappdata}\RootsVoice');
    if DirExists(DataDir) and (not UninstallSilent) then
      if MsgBox('Also delete your RootsVoice settings, training and downloaded speech models?' + #13#10 + #13#10 +
                'Choose No to keep them for a future install.', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
        DelTree(DataDir, True, True, True);
  end;
end;
