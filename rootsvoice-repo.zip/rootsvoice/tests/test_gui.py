"""Window tests: builds the whole RootsVoice window on a stand-in toolkit and drives it.

Run from the repository root:  python tests/test_gui.py
Needs only numpy - the speech engine, microphone and window toolkit are replaced by stand-ins.
"""
import sys, os, json, time, tempfile, queue, types
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(HERE, "faketk"))
sys.path.insert(1, ROOT)
import numpy as np
import tkinter as tk
from tkinter import messagebox, simpledialog
import rootsvoice as r

tmp = tempfile.mkdtemp()
for k in ("ALIASES_FILE", "REPLACEMENTS_FILE", "SOUNDALIKES_FILE", "PROMPTS_FILE", "SETTINGS_FILE"):
    setattr(r, k, os.path.join(tmp, k))
r.TRAINING_DIR = os.path.join(tmp, "train")
r.SAMPLES_INDEX = os.path.join(r.TRAINING_DIR, "samples.json")
r.CORRECTIONS_INDEX = os.path.join(r.TRAINING_DIR, "corrections.json")
r.MODELS_DIR = os.path.join(tmp, "models")
r.BUNDLED_MODELS_DIR = os.path.join(tmp, "bundled")
r.compile_patterns()
r.needs_install = lambda: False   # the startup install prompt is tested on its own below

ok_all, n = True, 0
def C(name, got, want):
    global ok_all, n
    n += 1
    if got != want:
        ok_all = False
        print(f"FAIL {name}: got {got!r}, want {want!r}")

sent, pressed = [], []
r.send_reference = lambda ref, s: (sent.append(ref), (True, f"Sent {ref}"))[1]
r.press_in_target = lambda keys, s, label, api_action=None: (pressed.append(keys), (True, label))[1]

queues = []
real_Queue = queue.Queue
def QF(*a, **k):
    q = real_Queue(*a, **k); queues.append(q); return q
r.queue.Queue = QF

def build(settings):
    tk.ALL.clear(); queues.clear()
    json.dump(settings, open(r.SETTINGS_FILE, "w"))
    r.run_gui()
    root = tk.Misc._root
    return root, queues[0]

def buttons():
    out = []
    for w in tk.ALL:
        if isinstance(w, tk.Canvas) and not w.destroyed:
            for fn in w.bindings.get("<ButtonRelease-1>", []):
                obj = getattr(fn, "__self__", None)
                if isinstance(obj, r.Button):
                    out.append(obj)
    return out

def btn(text=None, icon=None):
    for b in reversed(buttons()):
        if (text is None or b.text == text) and (icon is None or b.icon_name == icon):
            return b
    raise KeyError(text or icon)

def var_with(value):
    for w in tk.ALL:
        v = w.opts.get("textvariable") if not w.destroyed else None
        if v is not None and v.get() == value:
            return v
    raise KeyError(value)

def first(icon):
    return next(b for b in buttons() if b.icon_name == icon)

def step(root, rounds=2):
    for _ in range(rounds):
        time.sleep(0.12)
        root.run_after()

# ================= build in light mode =================
root, events = build({"roots_auto": True, "next_key": "down", "clear_key": "ctrl+b"})
C("window title", root.title_, "RootsVoice")
C("window icon set (logo)", len(root.icons or ()), 2)
labels = [b.text for b in buttons()]
for t in ("Start listening", "Live", "Training", "Settings", "Back", "Skip", "Clear", "Listen", "Record",
          "Save correction", "It was right", "Re-learn everything", "Learned words", "Import sermon recordings",
          "Confirm", "Countdown", "Listening", "Moving through scripture", "Projection software",
          "When RootsAuto is off", "Display", "Quick start", "Voice commands", "Keyboard shortcuts",
          "Troubleshooting", "Open"):
    C("has button " + t, t in labels, True)
light_bg = root.opts.get("bg")
C("light background", light_bg, r.THEMES["light"]["bg"])
badge = [w for w in tk.ALL if isinstance(w, tk.Canvas) and any(v[0] == "image" for v in w.items.values())]
C("logo badge drawn", len(badge) >= 1, True)

# ================= night mode =================
moon = btn(icon="moon")
moon.invoke()
C("night background", root.opts.get("bg"), r.THEMES["dark"]["bg"])
C("header button now sun", moon.icon_name, "sun")
C("night mode saved", json.load(open(r.SETTINGS_FILE))["theme"], "dark")
cards = [w for w in tk.ALL if isinstance(w, tk.Canvas) and any(v[0] == "polygon" and v[2].get("fill") == r.THEMES["dark"]["surface"] for v in w.items.values())]
C("cards repainted dark", len(cards) > 5, True)
moon.invoke()
C("back to light", root.opts.get("bg"), light_bg)

# ================= RootsAuto =================
def say(text, tail=""):
    events.put(("text", (tail + " " + text).strip(), text, np.zeros(1600, "float32")))
    step(root)

say("brothers and sisters God is good")
C("unrelated speech ignored", sent, [])
C("activity shows ignored count", any("1 unrelated phrase ignored" in b.text for b in buttons()), True)
say("let us turn to John chapter three verse sixteen")
C("RootsAuto sends instantly", sent, ["John 3:16"])
C("now showing", var_with("John 3:16").get(), "John 3:16")
chips = [b.text for b in buttons() if b.kind in ("chip", "chip_accent") and not b.text.isdigit()]
C("suggestion chips", chips, ["John 3:17", "John 3:15", "Whole chapter", "John 4"])
say("next verse")
C("next verse uses the key", pressed, ["down"])
say("John 3 this 20")
C("sound-alike in live speech", sent[-1], "John 3:20")
btn("Back").invoke(); step(root)
C("Back", sent[-1], "John 3:17")
say("clear the screen")
C("clear key", pressed[-1], "ctrl+b")
btn("John 3:18").invoke(); step(root)
C("chip click sends", sent[-1], "John 3:18")

# ================= RootsAuto off: confirm flow =================
sw = [w for w in tk.ALL if isinstance(w, tk.Canvas) and any(getattr(f, "__self__", None).__class__ is r.Switch
                                                             for f in w.bindings.get("<ButtonRelease-1>", []))]
auto_switch = sw[0].bindings["<ButtonRelease-1>"][0].__self__
auto_switch.toggle()
C("RootsAuto off saved", json.load(open(r.SETTINGS_FILE))["roots_auto"], False)
say("Romans eight twenty eight")
C("paused: waits", sent[-1], "John 3:18")
C("ready to send caption", var_with("READY TO SEND").get(), "READY TO SEND")
C("Send button shown", btn("Send").manager is not None, True)
btn("Send").invoke(); step(root)
C("Send sends", sent[-1], "Romans 8:28")
C("Send hidden again", btn("Send").manager, None)

# ================= typed entry with completion chips =================
mv = [w.opts["textvariable"] for w in tk.ALL if isinstance(w, tk.Entry) and not w.destroyed][0]
mv.set("1 pe")
entry = [w for w in tk.ALL if isinstance(w, tk.Entry)][0]
entry.fire("<KeyRelease>")
C("book completion chip", [b.text for b in buttons() if b.kind == "chip" and not b.text.isdigit()], ["1 Peter"])
btn("1 Peter").invoke()
C("completion fills box", mv.get(), "1 Peter ")
mv.set("1 Peter 2:9"); entry.fire("<Return>"); step(root)
C("typed reference sent", sent[-1], "1 Peter 2:9")

# ================= destroyed chips don't break theme switching =================
btn(icon="moon").invoke(); btn(icon="sun").invoke()
C("theme switch after chips destroyed", root.opts.get("bg"), light_bg)

# ================= training screen: listen & correct =================
btn("Training").invoke()
C("nav shows training", btn("Training").kind, "seg_on")
tab = None
for f in root.pending_after:
    obj = getattr(f[1], "__self__", None)
    if isinstance(obj, r.TrainingTab):
        tab = obj
C("training tab alive", tab is not None, True)
class Seg:
    def __init__(s, t): s.text = t; s.end = 1.0
class FakeModel:
    def transcribe(self, audio, **kw):
        return iter([Seg("turn to John 3 this 16")]), types.SimpleNamespace(duration=1.0)
r.get_model = lambda *a, **k: FakeModel()
def fake_open():
    tab.frames = [np.full((16000, 1), 0.3, "float32")]; tab.stream = types.SimpleNamespace(stop=lambda: 0, close=lambda: 0)
    tab.t0 = time.time(); return True
tab._open_mic = fake_open
btn("Listen").invoke()
C("listen button becomes Stop", btn(icon="stop").text in ("Stop", "Stop listening"), True)
tab.toggle_listen()
for _ in range(20):
    time.sleep(0.05); tab._poll()
    if tab.heard_text: break
C("heard text shown", tab.heard_var.get(), "turn to John 3 this 16")
C("sound-alike chip", tab.sound_var.get(), "“this” sounds like “verse” here")
C("would show", tab.detect_var.get(), "✓ Would show John 3:16")
C("save enabled", tab.save_corr_btn.state, "normal")
tab.heard_var.set("turn to John 3 verse 16"); tab.save_correction_click()
C("saved correction", json.load(open(r.CORRECTIONS_INDEX))[-1]["correct"], "turn to John 3 verse 16")
C("stats updated", tab.stat_vars["corr"].get(), "1")
btn("Learned words").invoke()
C("learned words dialog opens", any(isinstance(w, tk.Toplevel) and not w.destroyed for w in tk.ALL), True)
btn("Edit").invoke()
C("prompt editor opens", sum(isinstance(w, tk.Toplevel) for w in tk.ALL), 2)

# ================= settings =================
btn("Settings").invoke()
btn("Countdown").invoke()
C("countdown mode", btn("Countdown").kind, "seg_on")
root.close_fn()
saved = json.load(open(r.SETTINGS_FILE))
C("settings saved on close", (saved["mode"], saved["theme"], saved["roots_auto"]), ("auto", "light", False))

# ================= starts in night mode =================
root, events = build({"theme": "dark"})
C("starts in night mode", root.opts.get("bg"), r.THEMES["dark"]["bg"])
C("night logo icon", btn(icon="sun").icon_name, "sun")

# ================= new: small screens, fold-outs, help, stepping, shortcuts =================
tk.Misc.SCREEN = (1366, 768)
root, events = build({"roots_auto": True})
C("laptop screen picks Compact", btn("Start listening").ui.size_name, "compact")
w, h = [int(x) for x in root.geom.split("+")[0].split("x")]
C("window fits a 768px-high screen", h <= 768 - 80, True)
C("window docked at the right edge", int(root.geom.split("+")[1]) + w <= 1366, True)

listening, display = btn("Listening"), btn("Display")
C("Listening open first", listening.icon_name, "up")
display.invoke()
C("opening Display closes Listening (accordion)", (display.icon_name, listening.icon_name), ("up", "down"))

btn(icon="help").invoke()
C("help page shows", btn(icon="help").kind, "primary")
C("nav buttons all off on help", [btn(x).kind for x in ("Live", "Training", "Settings")], ["seg_off"] * 3)
ks = btn("Keyboard shortcuts"); ks.invoke()
C("help section opens", ks.icon_name, "up")
C("quick start closed by accordion", btn("Quick start").icon_name, "down")
btn("Live").invoke()

sent.clear()
say("turn to Psalm 23 verse 4")
C("auto sent", sent, ["Psalm 23:4"])
verse_chips = [b.text for b in buttons() if b.text.isdigit()]
C("verse strip shows nearby verses", verse_chips, ["2", "3", "4", "5", "6"])
C("current verse highlighted", btn("4").kind, "chip_accent")
btn("6").invoke(); step(root)
C("click verse number jumps", sent[-1], "Psalm 23:6")
first("right").invoke(); step(root)
C("next arrow", sent[-1], "Psalm 23:7")
first("left").invoke(); step(root)
C("previous arrow", sent[-1], "Psalm 23:6")
events.put(("hotkey", "next")); step(root)
C("Ctrl+Alt+Right shortcut", sent[-1], "Psalm 23:7")
events.put(("hotkey", "prev_ch")); step(root)
C("Ctrl+Alt+Up shortcut", sent[-1], "Psalm 22")
events.put(("hotkey", "back")); step(root)
C("Ctrl+Alt+B shortcut", sent[-1], "Psalm 23:7")
say("roots next")
C("voice: Roots next", sent[-1], "Psalm 23:8")
say("roots three")
C("voice: Roots 3", sent[-1], "Psalm 23:3")
before = len(sent)
events.put(("hotkey", "auto")); step(root)
C("Ctrl+Alt+A turns RootsAuto off", json.load(open(r.SETTINGS_FILE))["roots_auto"], False)
say("romans 8 28")
C("paused after shortcut", len(sent), before)
class FakeEngine:
    def __init__(self, *a): self.stop_flag = __import__("threading").Event(); self.failed = False
    def start(self): pass
real_engine, r.Engine = r.Engine, FakeEngine
events.put(("hotkey", "listen")); step(root)
C("Ctrl+Alt+L starts listening", btn(icon="stop").text, "Stop listening")
events.put(("hotkey", "listen")); step(root)
C("Ctrl+Alt+L stops listening", btn("Start listening").icon_name, "mic")
r.Engine = real_engine

btn("Start listening").invoke()
for _ in range(30):
    step(root, 1)
    if btn("Start listening").icon_name == "mic" and any(b.text == "Start listening" for b in buttons()):
        break
pill = [w for w in tk.ALL if isinstance(w, tk.Canvas) and any("Error" in (x or "") for x in w.texts())]
C("mic failure shows an error instead of hanging", len(pill) >= 1, True)

size_box = [w for w in tk.ALL if isinstance(w, tk.ttk.Combobox) and w.opts.get("values") == ["Auto", "Compact", "Normal", "Large"]][-1]
size_box.opts["textvariable"].set("Large"); size_box.fire("<<ComboboxSelected>>")
C("size saved", json.load(open(r.SETTINGS_FILE))["size"], "large")
root.close_fn()
root, events = build(json.load(open(r.SETTINGS_FILE)))
C("Large size used after restart", btn("Start listening").ui.size_name, "large")
tk.Misc.SCREEN = (1920, 1080)

# ================= 2.2: misheard book, projection software, active microphone =================
sent_s, cleared = [], []
r.send_reference = lambda ref, s: (sent.append(ref), sent_s.append(dict(s)), (True, f"Sent {ref}"))[2]
r.press_in_target = lambda keys, s, label, api_action=None: (
    pressed.append(keys), cleared.append((keys, api_action, s.get("target"))), (True, label))[2]
root, events = build({"roots_auto": True})
sent.clear()
say("turn to psalm twenty three")
say("turn to Habakook chapter two verse four")
C("misheard book in RootsAuto: no Psalm 2:4", sent, ["Psalm 23"])
C("misheard book: Did you mean", "Did you mean Habakkuk 2:4?" in [b.text for b in buttons()], True)
btn("Did you mean Habakkuk 2:4?").invoke(); step(root)
C("Did you mean sends it", sent[-1], "Habakkuk 2:4")
C("...and learns the spelling", r.RefTracker().parse("habakook 2 4"), "Habakkuk 2:4")
say("open have a cook chapter nine")
C("unrecognised book with no guess: nothing sent", sent[-1], "Habakkuk 2:4")

import types as _types
WIN = _types.SimpleNamespace(title="BibleShow 5", left=100, top=50, width=800, height=600, isMinimized=False,
                             activate=lambda: None, restore=lambda: None)
fake_gw = _types.ModuleType("pygetwindow")
fake_gw.getWindowsWithTitle = lambda t: [WIN] if t and t.lower() in WIN.title.lower() else []
fake_gw.getAllTitles = lambda: [WIN.title, "RootsVoice"]
fake_pg = _types.ModuleType("pyautogui")
fake_pg.position = lambda: (412, 138)
sys.modules["pygetwindow"], sys.modules["pyautogui"] = fake_gw, fake_pg

prog_box = [w for w in tk.ALL if isinstance(w, tk.ttk.Combobox) and "BibleShow" in (w.opts.get("values") or [])][-1]
def choose(name):
    prog_box.opts["textvariable"].set(name); prog_box.fire("<<ComboboxSelected>>")
    return json.load(open(r.SETTINGS_FILE))
saved = choose("BibleShow")
C("switch to BibleShow: F5", (saved["target"], saved["window_title"], saved["focus"], saved["search_hotkey"]),
  ("bibleshow", "BibleShow", "hotkey", "f5"))
C("VideoPsalm's settings kept", saved["targets"]["videopsalm"]["search_hotkey"], "ctrl+f")
C("Shortcut selected", btn("Shortcut").kind, "seg_on")
C("BibleShow guidance shown", var_with(r.TARGETS["bibleshow"]["note"]).get().startswith("BibleShow"), True)
C("RootsAuto names the program", any("Voice controls BibleShow" in (w.opts.get("textvariable").get() or "")
                                     for w in tk.ALL if w.opts.get("textvariable") is not None
                                     and isinstance(w.opts.get("textvariable").get(), str)), True)
btn("Send a test verse (John 3:16)").invoke(); step(root)
C("test verse goes to BibleShow with F5", (sent[-1], sent_s[-1]["target"], sent_s[-1]["search_hotkey"]),
  ("John 3:16", "bibleshow", "f5"))
say("turn to Romans eight twenty eight")
C("RootsAuto sends to BibleShow", (sent[-1], sent_s[-1]["target"]), ("Romans 8:28", "bibleshow"))
WIN.title = "EasyWorship 7"
saved = choose("EasyWorship")
C("EasyWorship uses pointing", (saved["focus"], btn("Pointing").kind), ("click", "seg_on"))
btn("Point to it").invoke()
for _ in range(7):
    root.run_after()
saved = json.load(open(r.SETTINGS_FILE))
C("pointed reference box saved", (saved["click_x"], saved["click_y"]), (312, 88))
btn("Send a test verse (John 3:16)").invoke(); step(root)
C("test verse goes to EasyWorship", (sent[-1], sent_s[-1]["target"], sent_s[-1]["click_x"]), ("John 3:16", "easyworship", 312))

fake_gw.getAllTitles = lambda: ["FreeShow - Sunday", "RootsVoice"]
btn("Detect").invoke()
C("Detect finds FreeShow", json.load(open(r.SETTINGS_FILE))["target"], "freeshow")
btn("Clear").invoke(); step(root)
C("FreeShow Clear uses its API", cleared[-1][1:], ("clear_all", "freeshow"))
saved = choose("EasyWorship")
C("EasyWorship's pointed box remembered", (saved["click_x"], saved["click_y"]), (312, 88))
saved = choose("BibleShow")
C("BibleShow still F5", (saved["focus"], saved["search_hotkey"]), ("hotkey", "f5"))
saved = choose("VideoPsalm")
C("back to VideoPsalm and Ctrl+F", (saved["target"], saved["focus"], saved["search_hotkey"]), ("videopsalm", "hotkey", "ctrl+f"))
del sys.modules["pygetwindow"], sys.modules["pyautogui"]

def fake_scan(progress=None, cancel=None, seconds=0.8):
    progress(1, 2, "Laptop mic")
    return [{"name": "Laptop mic", "ok": True, "level": 0.002, "loopback": False, "note": "Works, but quiet right now"},
            {"name": "Focusrite USB", "ok": True, "level": 0.05, "loopback": False, "note": "Hearing sound"}]
r.scan_microphones = fake_scan
btn("Find active microphone").invoke()
for _ in range(10):
    time.sleep(0.05); root.run_after()
C("mic scan names the most active", var_with("Most active: Focusrite USB").get(), "Most active: Focusrite USB")
use = [b for b in buttons() if b.text == "Use"]
C("a Use button per working mic, best highlighted", [b.kind for b in use], ["secondary", "primary"])
use[1].invoke()
C("chosen mic saved", json.load(open(r.SETTINGS_FILE))["mic"], "Focusrite USB")
events.put(("warn", "No sound from the microphone for 20 seconds - check it isn't muted.")); step(root)
C("silence warning shown", var_with("No sound from the microphone for 20 seconds - check it isn't muted.").get()[:8], "No sound")

# ================= 2.2.2: microphone dropdown and driver notices =================
fake_sd = _types.ModuleType("sounddevice")
MICS = [{"name": "Microsoft Sound Mapper - Input", "max_input_channels": 2, "default_samplerate": 44100},
        {"name": "Microphone Array (Realtek)", "max_input_channels": 2, "default_samplerate": 48000},
        {"name": "USB Mic", "max_input_channels": 1, "default_samplerate": 48000}]
fake_sd.query_devices = lambda device=None, kind=None: MICS if device is None and kind is None else MICS[1]
sys.modules["sounddevice"] = fake_sd
root, events = build({"mic": "Old Headset"})
mic_box = [w for w in tk.ALL if isinstance(w, tk.ttk.Combobox)
           and any(str(v).startswith("Windows default") for v in (w.opts.get("values") or []))][-1]
C("dropdown: Windows default by name, every mic, unplugged one marked", mic_box.opts["values"],
  ["Windows default (Microphone Array (Realtek))", "Microphone Array (Realtek)", "USB Mic", "Old Headset (not connected)"])
C("dropdown shows the saved mic", mic_box.opts["textvariable"].get(), "Old Headset (not connected)")
mic_box.opts["textvariable"].set("USB Mic"); mic_box.fire("<<ComboboxSelected>>")
C("picking a mic saves it", json.load(open(r.SETTINGS_FILE))["mic"], "USB Mic")
mic_box.opts["textvariable"].set("Windows default (Microphone Array (Realtek))"); mic_box.fire("<<ComboboxSelected>>")
C("picking Windows default saves ''", json.load(open(r.SETTINGS_FILE))["mic"], "")
MICS.append({"name": "Webcam Mic", "max_input_channels": 1, "default_samplerate": 16000})
[b for b in buttons() if b.icon_name == "refresh" and not b.text][0].invoke()
C("refresh finds a newly plugged mic", "Webcam Mic" in mic_box.opts["values"], True)
C("mic count shown (Sound Mapper left out)", var_with("3 microphones found").get(), "3 microphones found")
del sys.modules["sounddevice"]

opened_links = []
r.open_windows_link = lambda target: (opened_links.append(target), True)[1]
driver_issue = r.microphone_health(mic_count=1, problems=[("USB Audio Device", "has no driver installed", 28)], blocked=False)
events.put(("mic_health", driver_issue)); step(root)
C("driver notice window opens", any(isinstance(w, tk.Toplevel) and w.title_ == "Microphone needs attention"
                                    for w in tk.ALL if not w.destroyed), True)
C("notice names the device", any(w.opts.get("text") == "⚠  'USB Audio Device' has no driver installed"
                                                        for w in tk.ALL if isinstance(w, tk.Label)), True)
btn("Look for driver updates").invoke()
C("button opens Windows driver updates", opened_links[-1], "ms-settings:windowsupdate-optionalupdates")
btn("Open Device Manager").invoke()
C("button opens Device Manager", opened_links[-1], "devmgmt.msc")

health_calls = []
r.microphone_health = lambda **kw: (health_calls.append(1), [{"title": "No microphone found", "detail": "Plug one in.",
                                                               "actions": [r.WIN_LINKS["sound"]]}])[1]
before = sum(isinstance(w, tk.Toplevel) for w in tk.ALL)
events.put(("error", "Could not open the microphone: Windows couldn't open the microphone: no driver is installed for it"))
for _ in range(10):
    time.sleep(0.05); root.run_after()
C("microphone error -> notice explains the fix", (len(health_calls), sum(isinstance(w, tk.Toplevel) for w in tk.ALL) - before), (1, 1))

r.setup_check = lambda s: [(True, "Speech model 'base.en': ready"), (False, "Microphone: none found - plug one in")]
messagebox.LOG.clear()
btn("Check setup").invoke()
for _ in range(10):
    time.sleep(0.05); root.run_after()
C("Check setup runs and reports", any(e[0] == "info" and e[1] == "Check setup" and "No microphone found" in e[2]
                                      for e in messagebox.LOG), True)
btn("Open Sound settings").invoke()
C("Check setup offers the fix", opened_links[-1], "ms-settings:sound")

# ================= 2.2.3: install missing components from inside RootsVoice =================
r.needs_install = lambda: True
r.missing_dependencies = lambda include_optional=True: [("faster-whisper", "the speech engine that turns speech into text", True)]
install_calls = []
def fake_install(pkgs, log=print, run=None):
    install_calls.append(list(pkgs)); log("Collecting faster-whisper"); log("Successfully installed faster-whisper")
    return True, "Installed faster-whisper. Restart RootsVoice to start using them."
r.install_packages = fake_install
root, events = build({})
for _ in range(3):
    root.run_after()
dlg = [w for w in tk.ALL if isinstance(w, tk.Toplevel) and w.title_ == "Install components" and not w.destroyed]
C("startup: offers to install the speech engine", len(dlg), 1)
C("dialog says what is needed", any(w.opts.get("text") == "RootsVoice needs a few things" for w in tk.ALL if isinstance(w, tk.Label)), True)
btn("Install now").invoke()
for _ in range(20):
    time.sleep(0.03); root.run_after()
C("installs the missing component", install_calls, [["faster-whisper"]])
C("shows pip's progress", any("Successfully installed faster-whisper" in w.content for w in tk.ALL if isinstance(w, tk.Text)), True)
C("offers a restart when done", btn("Restart RootsVoice").manager is not None, True)
C("result shown", var_with("Installed faster-whisper. Restart RootsVoice to start using them.").get()[:9], "Installed")

r.install_packages = lambda pkgs, log=print, run=None: (False, "No internet connection - connect to the internet and try again (it's only needed once).")
events.put(("error", 'Missing package: faster-whisper. RootsVoice can install it for you (Help › Install missing components)'))
for _ in range(3):
    root.run_after()
C("missing component error -> install window", sum(isinstance(w, tk.Toplevel) and w.title_ == "Install components" for w in tk.ALL), 2)
btn("Install now").invoke()
for _ in range(20):
    time.sleep(0.03); root.run_after()
C("failure explained, can try again", (btn("Try again").state, var_with(
    "No internet connection - connect to the internet and try again (it's only needed once).").get()[:11]), ("normal", "No internet"))
btn("Install missing components").invoke()
C("Help button opens it too", sum(isinstance(w, tk.Toplevel) and w.title_ == "Install components" for w in tk.ALL), 3)

print(f"{n} GUI checks:", "ALL PASS" if ok_all else "SOME FAILED")
sys.exit(0 if ok_all else 1)
