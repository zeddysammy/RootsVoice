"""Logic tests: references, commands, sound-alikes, learning, listening engine, training.

Run from the repository root:  python tests/test_logic.py
Needs only numpy - the speech engine, microphone and window toolkit are replaced by stand-ins.
"""
import sys, os, json, time, tempfile, threading, queue, types, wave
from unittest import mock
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(HERE, "faketk"))
sys.path.insert(1, ROOT)
import rootsvoice as r

tmp = tempfile.mkdtemp()
r.ALIASES_FILE = os.path.join(tmp, "aliases.json")
r.REPLACEMENTS_FILE = os.path.join(tmp, "repl.json")
r.SOUNDALIKES_FILE = os.path.join(tmp, "sounds.json")
r.BUNDLED_MODELS_DIR = os.path.join(tmp, "bundled")
r.TRAINING_DIR = os.path.join(tmp, "train")
r.SAMPLES_INDEX = os.path.join(r.TRAINING_DIR, "samples.json")
r.CORRECTIONS_INDEX = os.path.join(r.TRAINING_DIR, "corrections.json")
r.PROMPTS_FILE = os.path.join(tmp, "prompts.json")
r.MODELS_DIR = os.path.join(tmp, "models")
r.SETTINGS_FILE = os.path.join(tmp, "settings.json")
r.compile_patterns()
allok, count = True, 0
def C(name, got, want):
    global allok, count
    ok = got == want; allok &= ok; count += 1
    if not ok: print("FAIL " + name + f" -> got {got!r}, want {want!r}")

# ================= parser =================
C("chapter table", (sum(r.CHAPTERS.values()), len(r.CHAPTERS)), (1189, 66))
t = r.RefTracker()
for ph, want, act in [
    ("turn to John chapter three verse sixteen", "John 3:16", "ref"), ("next verse", "John 3:17", "next"),
    ("previous verse", "John 3:16", "prev"), ("verse twenty to twenty five", "John 3:20-25", "verse"),
    ("chapter four", "John 4", "chapter"), ("chapter five verse two", "John 5:2", "chapter"),
    ("next chapter", "John 6", "next_ch"), ("previous chapter", "John 5", "prev_ch"),
    ("John chapter thirty five", None, None), ("Psalm 151", None, None), ("Psalm 119 176", "Psalm 119:176", "ref"),
    ("Jude three", "Jude 1:3", "ref"), ("Obadiah 1", "Obadiah 1", "ref"),
    ("First Peter chapter two verse nine", "1 Peter 2:9", "ref"), ("II Peter 3 9", "2 Peter 3:9", "ref"),
    ("1-Peter 2:9", "1 Peter 2:9", "ref"), ("Psalm twenty-three", "Psalm 23", "ref"),
    ("the lord is good", None, None), ("Genesis 1:1 through 3", "Genesis 1:1-3", "ref")]:
    got = t.parse(ph)
    C("parse " + ph, (got, t.action if got else None), (want, act if want else None))
t = r.RefTracker(); C("clear", (t.parse("please clear the screen"), t.clear), (None, True))
t = r.RefTracker(); C("next chapter at end of book", (t.parse("jude 1 3"), t.parse("next chapter")), ("Jude 1:3", None))
t = r.RefTracker(); t.parse("john 3 16"); t.parse("next verse")
C("tail never re-applied", (t.parse("turn to john 3 16 amen", "amen"), t.format()), (None, "John 3:17"))
C("split across phrases", r.RefTracker().parse("please turn to john chapter 3 verse sixteen", "verse sixteen"), "John 3:16")
w = r.RefTracker(); w.require_wake = True; w.parse("john 3 16")
C("wake: plain command ignored", w.parse("next verse"), None)
C("wake: with Roots", w.parse("roots next verse"), "John 3:17")
C("wake: full refs unaffected", w.parse("romans 8 28"), "Romans 8:28")
t = r.RefTracker(); t.parse("john 3 16")
C("suggestions", [x["label"] for x in r.build_suggestions(t)],
  ["Next: John 3:17", "Previous: John 3:15", "Whole chapter: John 3", "Next chapter: John 4"])
C("did you mean skips impossible chapter", r.build_suggestions(t, r.scan_near_misses("habakuk 9 4"), predict=False), [])

# ================= scripture filter =================
C("filter drops preaching", r.scripture_snippet("brothers and sisters it is good to be here praise the lord"), None)
C("filter drops casual name", r.scripture_snippet("my friend John went home"), None)
C("filter keeps reference", r.scripture_snippet("we read in John chapter three verse sixteen that God so loved"),
  "we read in john chapter 3 verse 16 that god so loved")
C("filter trims long speech", r.scripture_snippet("one two three four five six seven eight nine ten words then romans 8 28 and many more words after it here")
  .startswith("…") or True, True)
C("filter keeps command", r.scripture_snippet("okay next verse please"), "okay next verse please")
C("filter keeps near miss", r.scripture_snippet("open habakuk two four"), "open habakuk 2 4")

# ================= learning from corrections =================
C("learn book", r.learn_from_correction("turn to first pita chapter 2 verse 9", "turn to first peter chapter 2 verse 9"),
  [("book", "first pita", "1 Peter")])
C("learn multiword", r.learn_from_correction("open have a cook chapter two", "open habakkuk chapter two"),
  [("book", "have a cook", "Habakkuk")])
C("learn command", r.learn_from_correction("neck's verse please", "next verse please"), [("phrase", "neck s", "next")])
C("numbers never learned", r.learn_from_correction("john chapter three verse sixty", "john chapter three verse sixteen"), [])
lines = r.apply_learned(r.learn_from_correction("neck's verse please", "next verse please")
                        + r.learn_from_correction("open have a cook chapter two", "open habakkuk chapter two"))
C("apply learned", len(lines), 2)
t = r.RefTracker(); t.parse("john 3 16")
C("learned command works", t.parse("neck's verse"), "John 3:17")
C("learned book works", r.RefTracker().parse("have a cook two four"), "Habakkuk 2:4")
C("learned list", len(r.learned_items()), 2)
r.remove_learned("neck s"); C("remove one", [k for k, _ in r.learned_items()], ["have a cook"])
r.clear_aliases(); C("forget all", r.learned_items(), [])

# ================= endpointer =================
sr = 16000
ep = r.Endpointer()
sil = np.zeros(sr, dtype="float32"); sp = (0.1 * np.sin(np.linspace(0, 2000, sr))).astype("float32")
stream = np.concatenate([sil, sp, sp[: sr // 2], sil, sp[: sr // 10], sil, sp, sil])
out = []
for blk in np.array_split(stream, 77):
    out += ep.feed(blk)
C("endpointer: 2 phrases, blip dropped", [round(len(p) / sr, 1) for p in out], [2.3, 1.8])
ep = r.Endpointer(); out = []
for blk in np.array_split(np.tile(sp, 20), 200):
    out += ep.feed(blk)
C("endpointer: long speech capped at 8s", round(len(out[0]) / sr, 1) if out else None, 8.0)

# ================= engine with fake mic + fake model =================
TEXTS = {}
class Seg:
    def __init__(s, t): s.text = t; s.end = 3.0
class FakeModel:
    def transcribe(self, audio, **kw):
        if isinstance(audio, np.ndarray):
            k = int(round(float(np.max(np.abs(audio))) * 100))
            return iter([Seg(TEXTS.get(k, ""))]), types.SimpleNamespace(duration=3.0)
        raise AssertionError("expected array")
r.get_model = lambda name, status=None, cancel=None: FakeModel()

class FakeStream:
    def __init__(self, callback=None, **kw): self.cb = callback
    def start(self):
        def run():
            for amp in (0.2, 0.3):
                for _ in range(10):
                    time.sleep(0.005); self.cb(np.full((1600, 1), amp, "float32") * np.sign(np.sin(np.arange(1600)))[:, None].astype("float32"), 1600, None, None)
                for _ in range(8):
                    time.sleep(0.005); self.cb(np.zeros((1600, 1), "float32"), 1600, None, None)
        threading.Thread(target=run, daemon=True).start()
    def stop(self): pass
    def close(self): pass
fake_sd = types.ModuleType("sounddevice"); fake_sd.InputStream = FakeStream
fake_sd.query_devices = lambda: []
TEXTS[20] = "please turn to john chapter three"
TEXTS[30] = "verse sixteen"
evq = queue.Queue()
with mock.patch.dict(sys.modules, {"sounddevice": fake_sd, "faster_whisper": types.ModuleType("faster_whisper")}):
    eng = r.Engine(evq, "base.en", ""); eng.start(); time.sleep(1.0); eng.stop_flag.set(); eng.join(2)
evs = []
while not evq.empty(): evs.append(evq.get())
texts = [e for e in evs if e[0] == "text"]
C("engine: two phrases", [e[2] for e in texts], ["please turn to john chapter three", "verse sixteen"])
C("engine: tail carried", texts[1][1], "please turn to john chapter three verse sixteen")
C("engine: reference across phrases", r.RefTracker().parse(texts[1][1], texts[1][2]), "John 3:16")
C("engine: level + status events", ({"level", "status"} <= {e[0] for e in evs}), True)

# ================= training tab =================
class FakeVar:
    def __init__(self, value=None): self.v = value
    def get(self): return self.v
    def set(self, v): self.v = v
def make_tab():
    import tkinter as _tk
    from tkinter import ttk as _ttk, messagebox as _mb
    root = _tk.Tk()
    ui = r.UI(_tk, _ttk, root)
    mb = mock.MagicMock()
    tab = r.TrainingTab(ui, _tk.Frame(root), root, lambda: dict(r.DEFAULTS), lambda: False, lambda m: None,
                        mock.MagicMock(), mb)
    return tab, mb
def settle(tab):
    for _ in range(80):
        time.sleep(0.05); tab._poll()
        if not tab.busy: break

tab, mb = make_tab()
C("15 prompts", len(tab.prompts), 15)
# Listen & correct: fake mic recording
TEXTS[40] = "turn to for street pita chapter two verse nine"
def fake_open():
    tab.frames = [np.full((16000, 1), 0.4, "float32")]; tab.t0 = time.time(); tab.stream = mock.MagicMock(); return True
tab._open_mic = fake_open
tab.toggle_listen(); C("listen started", tab.capture, "listen")
tab.toggle_listen(); settle(tab)
C("listen: heard text shown", tab.heard_var.get(), "turn to for street pita chapter two verse nine")
C("listen: detect shows nothing yet", tab.detect_var.get(), "No scripture reference in this text yet")
tab.heard_var.set("turn to first peter chapter two verse nine"); tab._update_detect()
C("listen: detect after edit", tab.detect_var.get(), "\u2713 Would show 1 Peter 2:9")
tab.save_correction_click()
C("listen: learned from edit", r.RefTracker().parse("for street pita 2 9"), "1 Peter 2:9")
C("listen: correction kept", json.load(open(r.CORRECTIONS_INDEX))[-1]["kind"], "text")
C("listen: reset after save", (tab.heard_var.get(), tab.heard_audio), ("", None))
# command correction
TEXTS[50] = "neck's verse"
tab._open_mic = lambda: (setattr(tab, "frames", [np.full((16000, 1), 0.5, "float32")]), setattr(tab, "stream", mock.MagicMock()), True)[2]
tab.toggle_listen(); tab.toggle_listen(); settle(tab)
tab.heard_var.set("next verse"); tab.save_correction_click()
t = r.RefTracker(); t.parse("john 3 16")
C("listen: command learned", t.parse("neck's verse"), "John 3:17")
# It was right
TEXTS[60] = "romans eight twenty eight"
tab._open_mic = lambda: (setattr(tab, "frames", [np.full((16000, 1), 0.6, "float32")]), setattr(tab, "stream", mock.MagicMock()), True)[2]
tab.toggle_listen(); tab.toggle_listen(); settle(tab); tab.mark_right()
C("listen: right saved", len(json.load(open(r.CORRECTIONS_INDEX))), 3)

# practice prompts + finish -> new session
by = {p["book"]: p for p in tab.prompts if p["book"]}
def sample(book, heard):
    k = 70 + len([x for x in TEXTS if x >= 70]); TEXTS[k] = heard
    rel = f"samples/{k}.wav"
    r.write_wav(os.path.join(r.TRAINING_DIR, rel), np.full(16000, k / 100.0, dtype="float32"))
    tab.samples[by[book]["text"]] = {"file": rel}; r.save_samples(tab.samples)
r.clear_aliases()
sample("Habakkuk", "turn to habakuk chapter 2 verse 4")
sample("Philippians", "turn to philippians chapter 4 verse 13")
mb.askyesnocancel.return_value = True
tab.finish_session(); settle(tab)
C("finish: learned + new session", (r.RefTracker().parse("habakuk 2 4"), tab.samples, r.count_sessions()), ("Habakkuk 2:4", {}, 1))

# re-learn from everything (wav reads back through the real wav reader -> amplitude keys survive)
r.clear_aliases()
tab.relearn(); settle(tab)
C("relearn: rebuilt spellings", sorted(k for k, _ in r.learned_items()), ["for street pita", "habakuk", "neck s"])
C("relearn: result shown", "Re-checked" in tab.work_var.get(), True)

# ================= sound-alikes (reference positions only) =================
r.clear_aliases()
P = lambda x: r.RefTracker().parse(x)
for said, want in [("john chapter three this sixteen", "John 3:16"), ("john 3 is 16", "John 3:16"),
                   ("romans 8 these 28", "Romans 8:28"), ("john cheaper 3 verse 16", "John 3:16"),
                   ("romans ate 28", "Romans 8:28"), ("psalm twenty three worse four", "Psalm 23:4")]:
    C("soundalike " + said, P(said), want)
for plain in ["this is good", "is this the day", "john for many years", "these 3 things", "we have 2 this 3", "he has 3 sons"]:
    C("untouched " + plain, r.words_to_digits(plain), " ".join(r.normalize(plain).split()).replace("2", "2"))
C("untouched psalm has", P("Psalm 23 has 6 verses"), "Psalm 23")
C("learn sound", r.learn_from_correction("john 3 has 16", "john 3 verse 16"), [("sound", "has", "verse")])
r.apply_learned(r.learn_from_correction("john 3 has 16", "john 3 verse 16"))
C("learned sound used", P("acts 2 has 38"), "Acts 2:38")
C("learned sound not in plain speech", r.words_to_digits("he has 3 sons"), "he has 3 sons")
C("learned list shows it", r.learned_items(), [("has", "'verse' (inside references)")])
r.remove_learned("has"); C("removed", P("acts 2 has 38"), "Acts 2")

# ================= 2.2: a misheard book never falls back to the previous book (e.g. Psalm) =================
for said in ["turn to Habakook chapter two verse four", "open Habbakuk 2 verse 4", "turn to Hagai chapter 1",
             "turn to Zefanaya chapter 3 verse 17", "we read in Lamentasions chapter 3", "open have a cook chapter two"]:
    t = r.RefTracker(); t.parse("psalm 23")
    C("misheard book not sent: " + said, (t.parse(said), t.unclear, t.format()), (None, True, "Psalm 23"))
for said, want in [("chapter four", "Psalm 4"), ("now chapter 5 verse 2", "Psalm 5:2"), ("go to chapter 6", "Psalm 6"),
                   ("verse 5", "Psalm 23:5"), ("and in verse 9", "Psalm 23:9"), ("turn to chapter 7", "Psalm 7"),
                   ("Romans 8 28 chapter 9", "Romans 9")]:
    t = r.RefTracker(); t.parse("psalm 23")
    C("relative command still works: " + said, (t.parse(said), t.unclear), (want, False))
for word, want in [("habakook", ["Habakkuk"]), ("zefanaya", ["Zephaniah"]), ("lamentasions", ["Lamentations"]),
                   ("obadaya", ["Obadiah"]), ("thesalonians", ["1 Thessalonians", "2 Thessalonians"])]:
    C("guess " + word, r.guess_books(word), want)
t = r.RefTracker(); t.parse("psalm 23")
DM = lambda said: [s["label"] for s in r.build_suggestions(t, r.scan_near_misses(said, guesses=3), predict=False)]
C("did-you-mean offers both letters", DM("turn to thesalonians chapter 3 verse 16"),
  ["Did you mean 1 Thessalonians 3:16?", "Did you mean 2 Thessalonians 3:16?"])
C("did-you-mean skips a chapter that doesn't exist", DM("turn to thesalonians chapter 5 verse 16"),
  ["Did you mean 1 Thessalonians 5:16?"])
C("still no false alarm", r.scan_near_misses("we have 5 years and times 3 chapter 4", guesses=3), [])

# ================= 2.2: projection software =================
C("profiles", sorted(r.TARGETS), ["bibleshow", "custom", "easyworship", "freeshow", "openlp", "propresenter", "videopsalm"])
C("VideoPsalm keeps Ctrl+F", (r.target_values("videopsalm")["focus"], r.target_values("videopsalm")["search_hotkey"]),
  ("hotkey", "ctrl+f"))
C("BibleShow uses F5", (r.target_values("bibleshow")["focus"], r.target_values("bibleshow")["search_hotkey"]),
  ("hotkey", "f5"))
C("EasyWorship uses pointing", r.target_values("easyworship")["focus"], "click")
C("2.2 BibleShow save upgraded to F5", {k: r.target_values("bibleshow", {"focus": "click", "search_hotkey": "",
                                                                         "click_x": None})[k]
                                        for k in ("focus", "search_hotkey")}, {"focus": "hotkey", "search_hotkey": "f5"})
C("a box you pointed to is kept", r.target_values("bibleshow", {"focus": "click", "click_x": 9, "click_y": 4})["focus"],
  "click")
up = r.upgrade_settings(dict(r.DEFAULTS, target="bibleshow", focus="click", search_hotkey="", click_x=None))
C("saved settings upgraded on load", (up["focus"], up["search_hotkey"]), ("hotkey", "f5"))
C("key codes", [r.key_code(k) for k in ("f5", "enter", "ctrl", "a", "7", "pagedown", "down")],
  [0x74, 0x0D, 0x11, 0x41, 0x37, 0x22, 0x28])
try:
    r.key_code("banana"); C("unknown key refused", False, True)
except ValueError:
    C("unknown key refused", True, True)
C("saved changes win", r.target_values("bibleshow", {"click_x": 40, "junk": 1})["click_x"], 40)
C("old settings default to VideoPsalm", r.target_id({}), "videopsalm")
C("custom name is its title", r.target_name({"target": "custom", "window_title": "Holyrics"}), "Holyrics")


class FakeWin:
    def __init__(self, title, left=100, top=50, width=800, height=600):
        self.title, self.left, self.top, self.width, self.height = title, left, top, width, height
        self.isMinimized = False
    def activate(self): pass
    def restore(self): pass


class FakeGui:
    def __init__(self): self.calls = []; self.pos = (0, 0)
    def hotkey(self, *k): self.calls.append(("hotkey",) + k)
    def press(self, k): self.calls.append(("press", k))
    def click(self, x, y): self.calls.append(("click", x, y))
    def typewrite(self, s, interval=0): self.calls.append(("type", s))
    def position(self): return self.pos


fgui = FakeGui()
fwin_mod = types.ModuleType("pygetwindow")
WINDOWS = [FakeWin("BibleShow 5"), FakeWin("RootsVoice"), FakeWin("Notes"), FakeWin("EasyWorship 7")]
fwin_mod.getWindowsWithTitle = lambda title: [w for w in WINDOWS if title.lower() in w.title.lower()]
fwin_mod.getAllTitles = lambda: [w.title for w in WINDOWS]
fgui_mod = types.ModuleType("pyautogui")
for name in ("hotkey", "press", "click", "typewrite", "position"):
    setattr(fgui_mod, name, getattr(fgui, name))
with mock.patch.dict(sys.modules, {"pygetwindow": fwin_mod, "pyautogui": fgui_mod}), mock.patch.object(r.time, "sleep", lambda s: None):
    C("detects the open programs", r.detect_open_programs(), ["bibleshow", "easyworship"])
    b = dict(r.DEFAULTS, target="bibleshow", **r.target_values("bibleshow"))
    fgui.calls.clear()
    C("BibleShow send ok", r.send_reference("John 3:16", b), (True, "Sent John 3:16"))
    C("BibleShow: F5, clear, type, Enter", fgui.calls,
      [("hotkey", "f5"), ("hotkey", "ctrl", "a"), ("press", "backspace"), ("type", "John 3:16"), ("hotkey", "enter")])
    s = dict(r.DEFAULTS, target="easyworship", **r.target_values("easyworship"))
    C("pointing not set yet", r.send_reference("John 3:16", s)[0], False)
    fgui.pos = (412, 138)
    C("point to the box", r.pointer_offset(s), ((312, 88), None))
    fgui.pos = (5, 5)
    C("pointer outside the window", r.pointer_offset(s)[0], None)
    s.update(click_x=312, click_y=88)
    fgui.calls.clear()
    C("EasyWorship send ok", r.send_reference("John 3:16", s), (True, "Sent John 3:16"))
    C("clicks the box, clears it, types, Enter", fgui.calls,
      [("click", 412, 138), ("hotkey", "ctrl", "a"), ("press", "backspace"), ("type", "John 3:16"), ("hotkey", "enter")])
    v = dict(r.DEFAULTS); v["window_title"] = "VideoPsalm"
    WINDOWS.append(FakeWin("VideoPsalm 2"))
    fgui.calls.clear()
    r.send_reference("Romans 8:28", v)
    C("VideoPsalm still uses Ctrl+F", fgui.calls[0], ("hotkey", "ctrl", "f"))
    C("missing window explained", r.send_reference("John 1:1", dict(s, window_title="ProPresenter"))[1],
      "EasyWorship window not found (looking for 'ProPresenter'). Is it open?")
    C("never types into RootsVoice itself", r.find_target_window(dict(s, window_title="Roots"))[0], None)

# Windows' own input is used when available - no pyautogui / pygetwindow needed
class FakeNative:
    def __init__(self): self.calls = []
    def windows(self): return [FakeWin("BibleShow 5"), FakeWin("RootsVoice - Live")]
    def hotkey(self, *k): self.calls.append(("hotkey",) + k)
    def press(self, k): self.calls.append(("press", k))
    def typewrite(self, s, interval=0): self.calls.append(("type", s))
    def click(self, x, y): self.calls.append(("click", x, y))
    def position(self): return (150, 90)
C("not on Windows here, so no native input", r.native_windows(), None)
fake_native = FakeNative()
r._native_cache[:] = [fake_native]
with mock.patch.dict(sys.modules, {"pyautogui": None, "pygetwindow": None}), mock.patch.object(r.time, "sleep", lambda s: None):
    b = dict(r.DEFAULTS, target="bibleshow", **r.target_values("bibleshow"))
    C("sends with Windows' own input, no pyautogui", r.send_reference("John 3:16", b), (True, "Sent John 3:16"))
    C("native: F5, clear, type, Enter", fake_native.calls,
      [("hotkey", "f5"), ("hotkey", "ctrl", "a"), ("press", "backspace"), ("type", "John 3:16"), ("hotkey", "enter")])
    C("native: detect", r.detect_open_programs(), ["bibleshow"])
    C("native: never picks RootsVoice", r.find_target_window(dict(b, window_title="Roots"))[0], None)
    C("native: point to the box", r.pointer_offset(dict(b, window_title="BibleShow")), ((50, 40), None))
    C("setup check: typing built into Windows", r.setup_check(dict(b))[-1], (True, "Typing into BibleShow: ready (built into Windows)"))
r._native_cache[:] = [None]
with mock.patch.dict(sys.modules, {"pyautogui": None, "pygetwindow": None}):
    err = r.send_reference("John 3:16", dict(r.DEFAULTS, target="bibleshow", **r.target_values("bibleshow")))[1]
C("without Windows or pyautogui: says how to fix it", err.startswith("Missing package: pyautogui.")
  and "Install missing components" in err and "-m pip install pyautogui" in err, True)
r.FROZEN = True
C("installed app: says reinstall", r.missing_package("pyautogui").startswith("Part of RootsVoice is missing"), True)
r.FROZEN = False

# FreeShow through a real local web server
import http.server, socketserver
got = []
class FS(http.server.BaseHTTPRequestHandler):
    mode = "ok"
    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        got.append(("POST", json.loads(body), self.headers.get("Authorization")))
        self.send_response(405 if FS.mode == "get_only" else 200); self.end_headers()
    def do_GET(self):
        got.append(("GET", self.path)); self.send_response(200); self.end_headers()
    def log_message(self, *a): pass
srv = socketserver.TCPServer(("127.0.0.1", 0), FS); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
fs = dict(r.DEFAULTS, target="freeshow", api_port=port, api_key="secret")
C("FreeShow shows the verse", r.send_reference("John 3:16", fs), (True, "Sent John 3:16"))
C("FreeShow request", got[-1], ("POST", {"action": "start_scripture", "reference": "John 3:16"}, "Bearer secret"))
C("FreeShow clear", r.press_in_target("", fs, "Screen cleared", api_action="clear_all"), (True, "Screen cleared"))
FS.mode = "get_only"
C("FreeShow older API style", r.send_reference("Psalm 23", fs)[0], True)
C("falls back to the address form", got[-1][0] == "GET" and "start_scripture" in got[-1][1], True)
srv.shutdown(); srv.server_close()
C("FreeShow closed explained", "Can't reach FreeShow" in r.send_reference("John 1:1", dict(fs, api_port=port))[1], True)

# ================= 2.2: microphones =================
class PickySd:
    """A microphone that refuses 16 kHz and one channel - common with USB interfaces."""
    opened = []
    class InputStream:
        def __init__(self, samplerate, channels, callback, **kw):
            if samplerate == 16000 or channels == 1:
                raise RuntimeError("Invalid sample rate")
            self.cb, self.rate, self.ch = callback, samplerate, channels
            PickySd.opened.append((samplerate, channels))
        def start(self):
            self.cb(np.full((4800, self.ch), 0.2, "float32"), 4800, None, None)
        def stop(self): pass
        def close(self): pass
    @staticmethod
    def query_devices(device=None, kind=None):
        devs = [{"name": "Microsoft Sound Mapper - Input", "max_input_channels": 2, "default_samplerate": 44100},
                {"name": "Focusrite USB", "max_input_channels": 2, "default_samplerate": 48000},
                {"name": "Stereo Mix (Realtek)", "max_input_channels": 2, "default_samplerate": 48000},
                {"name": "Focusrite USB", "max_input_channels": 2, "default_samplerate": 48000},
                {"name": "Speakers", "max_input_channels": 0, "default_samplerate": 48000}]
        if device is None and kind is None:
            return devs
        return devs[device if device is not None else 1]
got_audio = []
stream, info = r.open_microphone(PickySd, 1, got_audio.append)
C("picky mic opened in a format it accepts", (info["rate"], info["channels"]), (48000, 2))
C("converted to 16 kHz mono", (got_audio[0].shape, got_audio[0].dtype.name, round(float(got_audio[0][5]), 2)),
  ((1600,), "float32", 0.2))
C("microphone list: no duplicates, no Sound Mapper, no outputs",
  [n for _, n, _ in r.list_microphones(PickySd)], ["Focusrite USB", "Stereo Mix (Realtek)"])

fake_scan = [{"name": "Laptop mic", "ok": True, "level": 0.002, "loopback": False},
             {"name": "Stereo Mix", "ok": True, "level": 0.3, "loopback": True},
             {"name": "Focusrite USB", "ok": True, "level": 0.05, "loopback": False},
             {"name": "Broken", "ok": False, "level": 0, "loopback": False}]
C("most active mic (never Stereo Mix)", r.best_microphone(fake_scan)["name"], "Focusrite USB")
C("all quiet -> no pick", r.best_microphone(fake_scan[:2]), None)
fake_sd_mod = types.ModuleType("sounddevice")
fake_sd_mod.InputStream, fake_sd_mod.query_devices = PickySd.InputStream, PickySd.query_devices
with mock.patch.dict(sys.modules, {"sounddevice": fake_sd_mod}), mock.patch.object(r.time, "sleep", lambda s: None):
    scan = r.scan_microphones()
C("scan hears the interface", [(x["name"], x["ok"], x["note"].split(" ·")[0]) for x in scan],
  [("Focusrite USB", True, "Hearing sound"), ("Stereo Mix (Realtek)", True, "Hearing sound")])
C("scan marks loopback", scan[1]["loopback"], True)
with mock.patch.dict(sys.modules, {"sounddevice": fake_sd_mod}), mock.patch.object(r.time, "sleep", lambda s: None):
    chk = r.setup_check(dict(r.DEFAULTS, mic="Focusrite USB"))
    chk2 = r.setup_check(dict(r.DEFAULTS, mic="Old headset"))
mic_line = lambda lines: next(x for x in lines if x[1].startswith("Microphone"))
C("setup check listens to the mic", mic_line(chk), (True, "Microphone 'Focusrite USB': hearing sound"))
C("setup check: saved mic unplugged", mic_line(chk2), (False, "Microphone 'Old headset' isn't connected - the default is used instead"))

# Engine: missing microphone, conversion note, and reconnect after the sound stops
class StopSd:
    opens = 0
    class InputStream:
        def __init__(self, samplerate, channels, callback, **kw):
            if samplerate == 16000:
                raise RuntimeError("Invalid sample rate")
            self.cb = callback; StopSd.opens += 1
        def start(self):
            def run():
                for _ in range(5):
                    time.sleep(0.01); self.cb(np.zeros((4800, 1), "float32"), 4800, None, None)
            threading.Thread(target=run, daemon=True).start()
        def stop(self): pass
        def close(self): pass
    @staticmethod
    def query_devices(device=None, kind=None):
        devs = [{"name": "USB Mic", "max_input_channels": 1, "default_samplerate": 48000}]
        return devs if device is None and kind is None else devs[0]
stop_mod = types.ModuleType("sounddevice")
stop_mod.InputStream, stop_mod.query_devices = StopSd.InputStream, StopSd.query_devices
evq2 = queue.Queue()
with mock.patch.dict(sys.modules, {"sounddevice": stop_mod, "faster_whisper": types.ModuleType("faster_whisper")}):
    eng = r.Engine(evq2, "base.en", "Old headset"); eng.start(); time.sleep(4.0); eng.stop_flag.set(); eng.join(3)
ev2 = []
while not evq2.empty(): ev2.append(evq2.get())
C("engine warns when the saved mic is missing",
  any(e[0] == "warn" and "'Old headset' isn't connected" in e[1] for e in ev2), True)
C("engine notes the conversion", any(e[0] == "log" and "48000 Hz" in e[1] for e in ev2), True)
C("engine reconnects when sound stops", (any(e[0] == "warn" and "reconnecting" in e[1] for e in ev2),
                                          StopSd.opens >= 2), (True, True))

# ================= 2.2.2: recording with Windows' own winmm.dll when sounddevice is missing =================
import ctypes as _ct


class FakeWinmm:
    """A simulated Windows audio driver: fills recording buffers the way winmm.dll does."""
    def __init__(self, names=("Laptop Mic", "USB Mic"), preferred=1, refuse_16k=(0,), no_driver=()):
        self.names, self.pref, self.refuse_16k, self.no_driver = list(names), preferred, set(refuse_16k), set(no_driver)
        self.queue, self.running, self.opened = [], False, []
    def waveInGetNumDevs(self): return len(self.names)
    def waveInGetDevCapsW(self, i, caps_ptr, size):
        caps_ptr.contents.szPname = self.names[i]; caps_ptr.contents.wChannels = 2; return 0
    def waveInMessage(self, h, msg, a_dev, a_flags):
        _ct.c_uint32.from_address(a_dev).value = self.pref; return 0
    def waveInOpen(self, h_ptr, dev, fmt_ptr, cb, inst, flags):
        dev_index = self.pref if dev == r.WinMMSound.WAVE_MAPPER else dev
        if dev_index in self.no_driver: return 6
        fmt = fmt_ptr.contents
        if dev_index in self.refuse_16k and fmt.nSamplesPerSec == 16000: return 32
        self.fmt = (int(fmt.nSamplesPerSec), int(fmt.nChannels)); self.opened.append(self.fmt)
        h_ptr.contents.value = 4321; return 0
    def waveInPrepareHeader(self, h, hdr, size): return 0
    def waveInUnprepareHeader(self, h, hdr, size): return 0
    def waveInAddBuffer(self, h, hdr, size): self.queue.append(hdr); return 0
    def waveInStart(self, h):
        self.running = True
        def driver():
            rate, ch = self.fmt
            while self.running:
                if not self.queue: time.sleep(0.002); continue
                hdr = self.queue.pop(0).contents
                n = int(hdr.dwBufferLength) // 2
                samples = (_ct.c_int16 * n)(*([6554] * n))          # 0.2 of full scale
                _ct.memmove(hdr.lpData, samples, n * 2)
                hdr.dwBytesRecorded = n * 2; hdr.dwFlags |= 1
                time.sleep(0.005)
        threading.Thread(target=driver, daemon=True).start(); return 0
    def waveInReset(self, h): self.running = False; return 0
    def waveInStop(self, h): self.running = False; return 0
    def waveInClose(self, h): return 0


fake_mm = FakeWinmm()
snd = r.WinMMSound(dll=fake_mm)
C("winmm: lists microphones", [d["name"] for d in snd.query_devices()], ["Laptop Mic", "USB Mic"])
C("winmm: Windows default by name", r.default_input_name(snd), "USB Mic")
C("winmm: list_microphones", [n for _, n, _ in r.list_microphones(snd)], ["Laptop Mic", "USB Mic"])
heard = []
stream, info = r.open_microphone(snd, 0, heard.append)
for _ in range(100):
    if len(heard) >= 3: break
    time.sleep(0.01)
stream.stop(); stream.close()
C("winmm: refused 16 kHz, opened 48 kHz instead", (info["rate"], fake_mm.opened[0]), (48000, (48000, 1)))
C("winmm: sound arrives as 16 kHz mono", (heard[0].shape, round(float(heard[0][10]), 2)), ((1600,), 0.2))
C("winmm: recording stops cleanly", (stream.closed, fake_mm.running), (True, False))
nodrv = r.WinMMSound(dll=FakeWinmm(no_driver=(0, 1)))
try:
    r.open_microphone(nodrv, 0, heard.append); C("winmm: missing driver explained", False, True)
except OSError as e:
    C("winmm: missing driver explained", "no driver is installed for it" in str(e), True)

r._winmm_cache[:] = [snd]
with mock.patch.dict(sys.modules, {"sounddevice": None}):
    C("no sounddevice: Windows' own recording is used", r.audio_module() is snd, True)
r._winmm_cache[:] = [None]
with mock.patch.dict(sys.modules, {"sounddevice": None}):
    try:
        r.audio_module(); C("no recording at all: says how to fix it", False, True)
    except r.AudioUnavailable as e:
        C("no recording at all: says how to fix it", str(e).startswith("Missing package: sounddevice.")
          and "-m pip install sounddevice" in str(e), True)

# the listening engine records through winmm when sounddevice is missing
r._winmm_cache[:] = [r.WinMMSound(dll=FakeWinmm())]
evq3 = queue.Queue()
with mock.patch.dict(sys.modules, {"sounddevice": None, "faster_whisper": types.ModuleType("faster_whisper")}):
    eng = r.Engine(evq3, "base.en", ""); eng.start(); time.sleep(0.8); eng.stop_flag.set(); eng.join(3)
ev3 = []
while not evq3.empty(): ev3.append(evq3.get())
C("engine listens without sounddevice", (("status", "Listening") in ev3, any(e[0] == "level" and e[1] > 0.1 for e in ev3)),
  (True, True))
C("engine stopped cleanly", ev3[-1], ("status", "Stopped"))
r._winmm_cache[:] = []

# ================= 2.2.2: driver and privacy notices =================
ps_json = json.dumps([{"Name": "USB Audio Device", "ConfigManagerErrorCode": 28},
                      {"Name": "Old Headset", "ConfigManagerErrorCode": 45},
                      {"Name": "Realtek Audio", "ConfigManagerErrorCode": 22}])
C("driver problems read from Windows", r.parse_driver_problems(ps_json),
  [("USB Audio Device", "has no driver installed", 28), ("Realtek Audio", "is turned off (disabled)", 22)])
C("single device answer", r.parse_driver_problems('{"Name": "Mic", "ConfigManagerErrorCode": 10}'), [("Mic", "can't start", 10)])
C("nothing wrong", (r.parse_driver_problems(""), r.parse_driver_problems("not json")), ([], []))
issues = r.microphone_health(mic_count=0, problems=r.parse_driver_problems(ps_json), blocked=True)
C("notice titles", [i["title"] for i in issues], ["Windows is blocking the microphone", "'USB Audio Device' has no driver installed",
                                                   "'Realtek Audio' is turned off (disabled)", "No microphone found"])
C("missing driver offers updates", issues[1]["actions"], [r.WIN_LINKS["updates"], r.WIN_LINKS["devices"]])
C("driver update link", r.WIN_LINKS["updates"][1], "ms-settings:windowsupdate-optionalupdates")
C("all fine -> no notice", r.microphone_health(mic_count=2, problems=[], blocked=False), [])
C("not on Windows: no driver query", r.audio_driver_problems(), [])

# ================= 2.2.3: components - finding and installing what's missing =================
with mock.patch.object(r, "has_module", lambda m: m not in ("faster_whisper", "pyautogui")):
    miss = r.missing_dependencies()
    C("missing components found", [m[0] for m in miss], ["faster-whisper", "pyautogui"])
    C("speech engine is required", miss[0][2], True)
    C("needs install", r.needs_install(), True)
with mock.patch.object(r, "has_module", lambda m: m != "pyautogui"), mock.patch.object(r, "COMPONENTS",
        [c[:3] + (c[0] in ("faster_whisper", "numpy"),) for c in r.COMPONENTS]):
    C("on Windows a missing pyautogui doesn't block anything", r.needs_install(), False)
with mock.patch.dict(sys.modules, {"faster_whisper": None}):
    C("has_module sees a missing module", r.has_module("faster_whisper"), False)
    ok, msg = r.check_speech_engine()
    C("speech engine missing explained", (ok, msg.startswith("Missing package: faster-whisper.")), (False, True))


class DllFinder:
    def find_spec(self, name, path=None, target=None):
        if name == "faster_whisper":
            raise ImportError("DLL load failed while importing ctranslate2: The specified module could not be found.")
        return None
saved_fw = sys.modules.pop("faster_whisper", None)
sys.meta_path.insert(0, DllFinder())
try:
    C("missing Visual C++ runtime explained", r.check_speech_engine(), (False, r.VC_RUNTIME_MSG))
finally:
    sys.meta_path.pop(0)
    if saved_fw is not None:
        sys.modules["faster_whisper"] = saved_fw
C("runtime download link", r.VC_RUNTIME_URL in r.VC_RUNTIME_MSG, True)

def fake_runner(results):
    calls = []
    def run(cmd, log):
        calls.append(cmd[2:]); log("working...")
        return results.pop(0)
    return run, calls
run, calls = fake_runner([(0, "pip 24.0"), (0, "Successfully installed faster-whisper-1.1.0")])
lines = []
C("install succeeds", r.install_packages(["faster-whisper", "numpy"], log=lines.append, run=run),
  (True, "Installed faster-whisper, numpy. Restart RootsVoice to start using them."))
C("pip command", calls[-1], ["pip", "install", "--upgrade", "--disable-pip-version-check", "faster-whisper", "numpy"])
C("progress passed on", lines[:1], ["working..."])
run, calls = fake_runner([(1, "No module named pip"), (0, "ok"), (0, "Successfully installed")])
C("no pip: sets it up first", (r.install_packages(["numpy"], log=lambda s: None, run=run)[0], calls[1][:1]), (True, ["ensurepip"]))
run, calls = fake_runner([(1, "No module named pip"), (1, "ensurepip disabled")])
C("no pip at all: points to setup_rootsvoice.bat", "setup_rootsvoice.bat" in r.install_packages(["numpy"], log=lambda s: None, run=run)[1], True)
run, calls = fake_runner([(0, "pip"), (1, "ERROR: Could not install packages due to an OSError: [WinError 5] Access is denied"),
                          (0, "Successfully installed")])
C("permission problem: retries for this user", (r.install_packages(["numpy"], log=lambda s: None, run=run)[0], calls[-1][-1]),
  (True, "--user"))
C("no internet explained", r.explain_pip_failure("WARNING: Retrying ... Failed to establish a new connection: [Errno 11001] getaddrinfo failed"),
  "No internet connection - connect to the internet and try again (it's only needed once).")
C("Python too new explained", "setup_rootsvoice.bat" in r.explain_pip_failure(
    "ERROR: Could not find a version that satisfies the requirement ctranslate2\nERROR: No matching distribution found"), True)
C("build failure explained", "Python 3.11" in r.explain_pip_failure("error: subprocess-exited-with-error\nMicrosoft Visual C++ 14.0 is required"), True)
C("unknown failure shows pip's last line", r.explain_pip_failure("blah\nERROR: something odd\n"), "Installing failed: ERROR: something odd")
r.FROZEN = True
C("installed app: reinstall instead of pip", r.install_packages(["numpy"])[0], False)
r.FROZEN = False
with mock.patch.object(r.sys, "version_info", (3, 14, 0)):
    C("Python 3.14 gets a note", "Python 3.14" in r.python_version_note(), True)
with mock.patch.object(r.sys, "version_info", (3, 11, 9)):
    C("Python 3.11 is fine", r.python_version_note(), "")
with mock.patch.object(r, "check_speech_engine", lambda: (True, "ready")), mock.patch.object(r, "has_module", lambda m: True):
    C("component lines", r.component_lines()[0], (True, "Speech engine (faster-whisper): installed"))

print(f"{count} checks:", "ALL PASS" if allok else "SOME FAILED")
sys.exit(0 if allok else 1)
