class Font:
    def __init__(self, root=None, family="x", size=10, weight="normal", **kw):
        self.family, self.size, self.weight = family, size, weight
    def measure(self, text):
        return int(len(text) * self.size * 0.62) + 1
def families(root=None):
    return ("Segoe UI", "Segoe UI Variable Text", "Segoe UI Variable Display", "Segoe Fluent Icons", "Consolas")
