LOG = []
ANSWER = None
def showinfo(*a, **kw): LOG.append(("info",) + a)
def showerror(*a, **kw): LOG.append(("error",) + a)
YES = False
def askyesno(*a, **kw): LOG.append(("yesno",) + a); return YES
def askyesnocancel(*a, **kw): LOG.append(("ync",) + a); return ANSWER
