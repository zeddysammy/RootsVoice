RESULT = ()
def askopenfilenames(**kw): return RESULT
