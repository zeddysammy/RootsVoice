from . import Misc
class Style:
    def __init__(self, root=None): self.conf = {}
    def theme_use(self, name=None): pass
    def configure(self, style, **kw): self.conf.setdefault(style, {}).update(kw)
    def map(self, style, **kw): pass
class Combobox(Misc): pass
class Progressbar(Misc): pass
