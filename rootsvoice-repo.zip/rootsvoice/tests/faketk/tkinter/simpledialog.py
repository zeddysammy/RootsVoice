ANSWER = None
def askstring(*a, **kw): return ANSWER
