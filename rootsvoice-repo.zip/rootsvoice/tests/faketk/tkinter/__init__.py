"""A small stand-in for tkinter, good enough to build and drive RootsVoice's window in tests."""
import itertools

ALL = []          # every widget ever created
_ids = itertools.count(1)


class TclError(Exception):
    pass


class _Var:
    _default = ""

    def __init__(self, master=None, value=None, name=None):
        self._v = self._default if value is None else value
        self._traces = []

    def get(self):
        return self._v

    def set(self, v):
        self._v = v
        for fn in list(self._traces):
            fn("", "", "write")

    def trace_add(self, mode, fn):
        self._traces.append(fn)


class StringVar(_Var):
    _default = ""


class IntVar(_Var):
    _default = 0


class BooleanVar(_Var):
    _default = False

    def get(self):
        return bool(self._v)


class PhotoImage:
    def __init__(self, master=None, data=None, file=None, **kw):
        if data is not None and not str(data).startswith("iVBOR"):
            raise TclError("couldn't recognize image data")
        self.data = data


class Misc:
    _root = None

    def __init__(self, master=None, **kw):
        self.master = master
        self.opts = {"width": 0, "height": 0}
        self.opts.update(kw)
        self.children_ = []
        self.bindings = {}
        self.manager = None
        self.destroyed = False
        if master is not None:
            master.children_.append(self)
        ALL.append(self)
        var = kw.get("textvariable")
        if var is not None and hasattr(var, "trace_add"):
            pass

    # ---- options
    def _alive(self):
        if self.destroyed:
            raise TclError("invalid command name (widget destroyed)")

    def configure(self, cnf=None, **kw):
        self._alive()
        if cnf:
            kw.update(cnf)
        self.opts.update(kw)

    config = configure

    def cget(self, key):
        self._alive()
        return self.opts.get(key, "")

    def __setitem__(self, k, v):
        self.configure(**{k: v})

    def __getitem__(self, k):
        return self.cget(k)

    # ---- geometry
    def pack(self, **kw):
        self._alive()
        self.manager = ("pack", kw)

    def grid(self, **kw):
        self._alive()
        self.manager = ("grid", kw)

    def place(self, **kw):
        self._alive()
        self.manager = ("place", kw)

    def pack_forget(self):
        self.manager = None

    grid_forget = grid_remove = place_forget = pack_forget

    def columnconfigure(self, *a, **kw):
        pass

    rowconfigure = columnconfigure

    # ---- events
    def bind(self, seq, fn=None, add=None):
        self.bindings.setdefault(seq, []).append(fn)

    def bind_all(self, seq, fn=None, add=None):
        pass

    def unbind_all(self, seq):
        pass

    def fire(self, seq, event=None):
        for fn in self.bindings.get(seq, []):
            fn(event)

    # ---- info
    def winfo_width(self):
        return int(float(self.opts.get("width") or 0)) or 400

    def winfo_height(self):
        return int(float(self.opts.get("height") or 0)) or 40

    def winfo_reqheight(self):
        return 40 + 30 * len(self.children_)

    def winfo_reqwidth(self):
        return 300

    def winfo_children(self):
        return [c for c in self.children_ if not c.destroyed]

    def winfo_ismapped(self):
        return self.manager is not None

    def winfo_fpixels(self, what):
        return 96.0

    SCREEN = (1920, 1080)

    def winfo_screenwidth(self):
        return Misc.SCREEN[0]

    def winfo_screenheight(self):
        return Misc.SCREEN[1]

    def winfo_exists(self):
        return not self.destroyed

    def destroy(self):
        self.destroyed = True
        for c in self.children_:
            c.destroy()

    def focus_set(self):
        pass

    def update_idletasks(self):
        pass

    def after(self, ms, fn=None, *args):
        root = self._root or self
        jid = f"after#{next(_ids)}"
        root.pending_after.append((jid, fn, args))
        return jid

    def after_cancel(self, jid):
        root = self._root or self
        root.pending_after = [a for a in root.pending_after if a[0] != jid]

    def option_add(self, *a, **kw):
        pass


class Tk(Misc):
    def __init__(self, **kw):
        super().__init__(None, **kw)
        self.pending_after = []
        Misc._root = self
        self.title_ = ""
        self.icons = None

    def title(self, t=None):
        self.title_ = t

    def geometry(self, g=None):
        self.geom = g

    def minsize(self, *a):
        pass

    def attributes(self, *a):
        pass

    def protocol(self, name, fn):
        self.close_fn = fn

    def iconphoto(self, default, *imgs):
        self.icons = imgs

    def mainloop(self):
        pass

    def run_after(self, rounds=1):
        """Run the scheduled callbacks once (like one turn of the event loop)."""
        for _ in range(rounds):
            jobs, self.pending_after = self.pending_after, []
            for jid, fn, args in jobs:
                fn(*args)


class Toplevel(Misc):
    def title(self, t=None):
        self.title_ = t

    def transient(self, master=None):
        pass

    def geometry(self, g=None):
        pass


class Frame(Misc):
    pass


class Label(Misc):
    pass


class Checkbutton(Misc):
    pass


class Spinbox(Misc):
    pass


class Canvas(Misc):
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw)
        self.items = {}

    def _create(self, kind, *coords, **kw):
        self._alive()
        i = next(_ids)
        self.items[i] = (kind, coords, kw)
        return i

    def create_polygon(self, *a, **kw):
        return self._create("polygon", *a, **kw)

    def create_text(self, *a, **kw):
        return self._create("text", *a, **kw)

    def create_oval(self, *a, **kw):
        return self._create("oval", *a, **kw)

    def create_image(self, *a, **kw):
        return self._create("image", *a, **kw)

    def create_window(self, *a, **kw):
        return self._create("window", *a, **kw)

    def delete(self, tag):
        self._alive()
        if tag == "all":
            self.items = {k: v for k, v in self.items.items() if v[0] == "window"}
        else:
            self.items = {k: v for k, v in self.items.items() if v[2].get("tags") != tag}

    def itemconfigure(self, item, **kw):
        pass

    def tag_lower(self, *a):
        pass

    def yview_scroll(self, *a):
        pass

    def texts(self):
        return [v[2].get("text") for v in self.items.values() if v[0] == "text"]


class Entry(Misc):
    def get(self):
        v = self.opts.get("textvariable")
        return v.get() if v is not None else ""

    def insert(self, i, s):
        v = self.opts.get("textvariable")
        if v is not None:
            v.set(v.get() + s)

    def delete(self, a, b=None):
        v = self.opts.get("textvariable")
        if v is not None:
            v.set("")

    def icursor(self, i):
        pass


class Text(Misc):
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw)
        self.content = ""

    def insert(self, idx, s):
        if self.opts.get("state") == "disabled":
            return
        self.content = s + self.content if idx == "1.0" else self.content + s

    def delete(self, a, b=None):
        self.content = ""

    def get(self, a, b=None):
        return self.content + ("\n" if b == "end" else "")

    def see(self, idx):
        pass


class Listbox(Misc):
    def __init__(self, master=None, **kw):
        super().__init__(master, **kw)
        self.items, self.sel = [], []

    def insert(self, i, x):
        self.items.append(x) if i == "end" else self.items.insert(int(i), x)

    def delete(self, a, b=None):
        if b is not None:
            self.items = []
        else:
            self.items.pop(-1 if a == "end" else int(a))

    def get(self, a, b=None):
        return list(self.items) if b is not None else self.items[a]

    def size(self):
        return len(self.items)

    def curselection(self):
        return tuple(self.sel)

    def selection_set(self, i):
        self.sel = [i]
