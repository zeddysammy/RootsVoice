# faketk

A small stand-in for Python's `tkinter`, so `tests/test_gui.py` can build and click through the RootsVoice window on any machine (including GitHub's test servers) without a screen.
