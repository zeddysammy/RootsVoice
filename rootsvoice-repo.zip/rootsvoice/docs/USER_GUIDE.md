# RootsVoice - Operator guide

For the person running projection during a service. For building and releasing, see [BUILDING.md](BUILDING.md).

## 1. First-time setup (once per computer)

1. Install with `RootsVoice-Setup-2.2.3.exe` and choose **Recommended**.
2. Open RootsVoice. It docks at the right side of the screen so your projection software stays visible.
3. **Settings → Listening → Find active microphone** - speak while it listens to each input, then press **Use** on the one that heard you. A feed from the sound desk (aux send into the PC's line-in or a USB audio interface) is far more accurate than a room microphone.
4. **Settings → Projection software** - open your program and press **Detect** (or pick it from the list). VideoPsalm (Ctrl+F) and BibleShow (F5) need nothing more. For EasyWorship, ProPresenter, OpenLP or another program, open its Bible panel, press **Point to it** and hold the mouse over the box where a reference is typed for 5 seconds. For FreeShow, turn on its API (FreeShow → Settings → Connections). Then press **Send a test verse**.
5. **Help (?) → Check setup.** Every line should show ✓.
6. Spend 10 minutes in **Training → Listen & correct** with each preacher (see section 4).

## 2. Service-day checklist

- [ ] Projection software open (Bible panel showing, if it has one), the right Bible version selected.
- [ ] RootsVoice open → **Check setup** shows all ✓.
- [ ] Press **Start listening**; the mic bars move when the preacher speaks.
- [ ] Decide: **RootsAuto on** (hands-free) or **off** (you confirm each verse).
- [ ] For the first services, turn on **Settings → Moving through scripture → Say "Roots" first**.
- [ ] Know the safety nets: **Back** / `Ctrl+Alt+B` undoes a wrong jump; `Ctrl+Alt+A` pauses RootsAuto.

## 3. During the service

**The Live screen, top to bottom**

| Part | What it does |
|---|---|
| Start / Stop listening | Turns the microphone on or off (`Ctrl+Alt+L`). |
| RootsAuto switch | On: references go on screen instantly. Off: they wait for **Send**. |
| Now showing | The current verse in large text. "Ready to send" (green outline) means it is waiting for you. |
| ‹ 14 15 **16** 17 18 › | Step or jump through verses of the current chapter. |
| Back · Skip · Clear | Undo the last jump · ignore a waiting verse · blank the screen (needs a Clear key in Settings, except FreeShow). |
| Suggestions | One click for next verse, previous verse, whole chapter, next chapter, or "Did you mean...?". |
| Type a reference | For anything the preacher didn't say clearly. Type "1 pe" and pick 1 Peter from the suggestions. |
| Recent | The last references shown - double-click one to show it again. |
| Activity | What it heard and did. Unrelated preaching is counted, not shown. |

**Moving through scripture** - most projection programs have no voice-friendly next / previous verse keys, so RootsVoice works out the new reference and sends it:

- Say "Roots next", "Roots back", "Roots 18", or "next verse", "previous verse", "chapter 4".
- Click the arrows or verse numbers under the current verse.
- `Ctrl+Alt+→` / `←` (verse), `Ctrl+Alt+↓` / `↑` (chapter) - work while your projection software is in front.
- A presentation clicker: **Settings → Moving through scripture → Presentation clicker**. Its forward / back buttons then step verses (it takes over Page Down / Page Up while on).

## 4. Training - teaching it your preacher's voice

Everything learned is used straight away. Ten minutes per preacher makes a real difference.

1. **Listen & correct** (best): press **Listen**, have the preacher say a reference, press **Stop**. If the text is wrong, fix it to what was really said and press **Save correction**; if right, press **It was right**. Focus on books it gets wrong.
2. **Practice prompts**: read each prompt, **Record**, then **Finish session** - after 15 or fewer. Use **Edit** to put your preacher's most-misheard books in the list.
3. **Live learning** (Settings → Display): during a service, click a misheard line, type the right reference, **Learn & send**.
4. **Import sermon recordings**: pick past sermon audio files; approve the misheard names it finds.
5. After choosing a bigger *Accuracy* model, press **Re-learn everything**.

Something learned wrongly? **Training → Learned words** → select it → **Remove**.

## 5. Settings at a glance

| Section | Highlights |
|---|---|
| Listening | Microphone and **Find active microphone**; Accuracy model (tiny / base / small / medium) and Download. |
| Moving through scripture | Keyboard shortcuts on/off; presentation clicker; "Say Roots first". |
| Projection software | Program + Detect; window title; shortcut or *Point to it*; keys after typing; verse separator; optional program keys; FreeShow API port and key; Send a test verse. |
| When RootsAuto is off | Confirm each verse, or Countdown (sends after a few seconds unless you Skip). |
| Display | Night mode; Size (Auto, Compact, Normal, Large); keep on top; live learning panel; show all speech. |

## 6. Where your data is

`%APPDATA%\RootsVoice` (Help → About → **Open**): settings, learned words, training recordings and downloaded models. Copy this folder to move RootsVoice's learning to another PC. Uninstalling asks whether to keep it.

## 7. Troubleshooting

| Problem | Fix |
|---|---|
| Stuck on "Downloading" | Needs internet once. Settings → Listening → Download on a good connection. |
| "... window not found" | Open the program; Settings → Projection software → Detect. |
| Verse typed in the wrong place | Open the program's Bible panel, then **Point to it** again. |
| Program comes to the front but nothing is typed | It runs as administrator - run RootsVoice as administrator too. |
| "Didn't catch the book name" | Pick from *Did you mean*; teach it in Listen & correct. |
| "Microphone needs attention" | Use its buttons: driver updates, Device Manager, or microphone privacy settings. |
| Mic bars don't move | **Find active microphone**; check the sound desk feed and Windows sound settings. |
| Wrong verse shown | **Back**, then teach it in Listen & correct. |
| Sermon words trigger commands | Turn on "Say Roots first". |
| Falling behind | Choose a smaller Accuracy model. |
| `Ctrl+Alt+arrows` rotate the screen | Turn off the graphics driver's hotkeys, or RootsVoice's shortcuts. |
| Window too big | Settings → Display → Size → Compact. |
