# Building and releasing RootsVoice

The installer is `RootsVoice-Setup-<version>.exe`, published by **nightfellas**. It contains RootsVoice packed by PyInstaller (no Python needed on church PCs) and, optionally, the `base.en` speech model so it works offline from the first launch.

## Option A - GitHub builds it (recommended)

No Windows PC needed. The workflow `.github/workflows/build-installer.yml` runs on GitHub's Windows servers.

- **Release build:** push a version tag. The installer is attached to a new GitHub Release.
  ```bash
  git tag v2.2.3
  git push origin v2.2.3
  ```
- **Test build:** *Actions → Build installer → Run workflow*. The installer appears under the run's **Artifacts**.

## Option B - build on a Windows PC

You need Windows 10/11 (64-bit), internet, ~3 GB free space, 10-20 minutes.

1. Double-click `build_installer.bat`.
2. Click **Yes** if Windows asks for permission (installing Python or Inno Setup).
3. When it says **Done**, `dist\RootsVoice-Setup-2.2.3.exe` is ready.

The script installs whatever is missing - Python 3.11 (build only), the libraries in `requirements.txt` plus PyInstaller, the speech model, and Inno Setup - then runs the same steps as the GitHub workflow. If a step fails it says why; run it again and finished steps are skipped. Build output goes to `build\` and `dist\`, both ignored by Git.

## What the build does

| Step | Tool | Output |
|---|---|---|
| 1 | Python 3.11 | private build environment in `build\venv` |
| 2 | pip | faster-whisper, sounddevice, numpy, pyautogui, pygetwindow, pyinstaller |
| 3 | `rootsvoice.py --download-model base.en build\models` | speech model to bundle |
| 4 | PyInstaller (`--onedir --windowed`, icon and `installer\version_info.txt`) | `build\pyinstaller\dist\RootsVoice\RootsVoice.exe` |
| 5 | Inno Setup (`installer\RootsVoice.iss`) | `dist\RootsVoice-Setup-<version>.exe` |

If the model download fails, the installer is built without it (`/DNOMODEL`) and RootsVoice downloads the model on first use.

## The installer wizard

Welcome → install for me / all users → Recommended or Smaller → folder → desktop shortcut and start-with-Windows → install → launch RootsVoice. Uninstalling asks whether to keep the user's settings and training in `%APPDATA%\RootsVoice`.

Branding lives in `assets\` (`roots.ico`, `wizard-large*.bmp` 164×314 / 328×628, `wizard-small*.bmp` 55×58 / 110×116). The publisher name *nightfellas* is set in `installer\RootsVoice.iss` (`MyAppPublisher`) and `installer\version_info.txt` (`CompanyName`).

**Never change `AppId`** in `RootsVoice.iss` - it is how Windows recognises upgrades.

## Code signing

Unsigned installers make Windows SmartScreen show *"Unknown publisher"*, and some antivirus tools are suspicious of new PyInstaller programs. Signing with a code-signing certificate issued to *nightfellas* fixes both.

Sign locally after building:

```bat
signtool sign /a /tr http://timestamp.digicert.com /td sha256 /fd sha256 dist\RootsVoice-Setup-2.2.3.exe
```

To sign in GitHub Actions, store the certificate as repository secrets and add a `signtool` step after the Inno Setup step (and ideally sign `RootsVoice.exe` before Inno Setup packs it).

## Releasing a new version

1. Update the version in `rootsvoice.py` (`APP_VERSION`), `installer\RootsVoice.iss` (`MyAppVersion`), `installer\version_info.txt` (four places) and the final message in `build_installer.bat`.
2. Move the notes in `CHANGELOG.md` under the new version.
3. Commit, tag `vX.Y`, push the tag - GitHub builds and publishes the installer.

## Third-party licences

The installer bundles open-source components under their own licences (listed in `LICENSE`). PyAV's wheels include FFmpeg libraries under the LGPL; keep the files PyInstaller copies from the `av` package intact and unmodified in the installed folder.
