## What this changes

<!-- One or two sentences. Link an issue if there is one: Fixes #12 -->

## How it was checked

- [ ] `python tests/test_logic.py` prints ALL PASS
- [ ] `python tests/test_gui.py` prints ALL PASS
- [ ] Tried it with VideoPsalm (if it affects sending, listening or the window)
- [ ] Looked at it in light **and** night mode (if it changes the window)

## Docs

- [ ] `CHANGELOG.md` updated
- [ ] `README.md` / `docs/` updated if operators will notice
