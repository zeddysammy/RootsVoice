RootsVoice 2.2.3 - installer kit
Publisher: nightfellas
==============================

This folder turns RootsVoice into a normal Windows installer,
RootsVoice-Setup-2.2.3.exe, with a step-by-step setup wizard.


MAKE THE INSTALLER (once)
-------------------------
You need: a Windows 10 or 11 PC (64-bit) with internet. About 3 GB of
free space while building. 10-20 minutes the first time.

  1. Unzip this folder somewhere simple, e.g. C:\RootsVoiceKit
  2. Double-click  build_installer.bat
  3. Click Yes if Windows asks for permission (installing Python or
     Inno Setup needs it). Leave the black window open.
  4. When it says Done, the "dist" folder opens with
     RootsVoice-Setup-2.2.3.exe inside.

The build script fetches everything by itself:
  - Python 3.11 (only used for building - the installer does not need it)
  - faster-whisper, sounddevice, numpy, pyautogui, pygetwindow
  - the base.en speech model, so RootsVoice works offline after installing
  - Inno Setup, which makes the wizard

If anything fails, it stops and says why. Fix it, then double-click
build_installer.bat again - finished steps are skipped.


INSTALL ROOTSVOICE ON A CHURCH PC
---------------------------------
Copy RootsVoice-Setup-2.2.3.exe to the PC (USB stick, shared folder,
email) and double-click it. The wizard asks:

  - Install for me only (no admin password) or for all users
  - Recommended (works offline) or Smaller (model downloads on first use)
  - Desktop shortcut, and whether to start with Windows

Nothing else needs installing - no Python, no libraries.

After installing, open RootsVoice > Help (the ? button) > Check setup.
It confirms the microphone, speech model and VideoPsalm are ready.

To uninstall: Windows Settings > Apps > RootsVoice > Uninstall.
You will be asked whether to keep your settings and training.


GOOD TO KNOW
------------
* "Windows protected your PC" / unknown publisher
  The installer says "nightfellas" everywhere (wizard, Apps list,
  file properties), but Windows SmartScreen only trusts a publisher
  name that is backed by a code-signing certificate. Until you sign
  it, click "More info" > "Run anyway" the first time.
  To sign: buy a code-signing certificate in the name nightfellas,
  then run   signtool sign /a /tr http://timestamp.digicert.com /td sha256 /fd sha256 dist\RootsVoice-Setup-2.2.3.exe

* Antivirus
  Some antivirus programs wrongly flag new, unsigned programs built
  with PyInstaller. Signing the installer fixes this too.

* Where things are kept after installing
  Program:   C:\Program Files\RootsVoice  (or your user folder)
  Settings, training and downloaded models:  %APPDATA%\RootsVoice
  (These survive upgrades - just run a newer Setup over the old one.)

* Size
  The installer is roughly 250-400 MB with the speech model included.


FILES IN THIS KIT
-----------------
  build_installer.bat        double-click to build everything
  rootsvoice.py              the RootsVoice program
  requirements.txt           libraries RootsVoice uses
  assets\roots.ico           app icon (Roots logo)
  assets\wizard-*.bmp        installer wizard artwork
  installer\RootsVoice.iss   the wizard recipe (Inno Setup)
  installer\version_info.txt publisher and version shown in file properties
